BackgroundExperimentYeast
=========

Experiment to measure NSB and optical noise in yeast. Information about object creation in /inst/scripts.